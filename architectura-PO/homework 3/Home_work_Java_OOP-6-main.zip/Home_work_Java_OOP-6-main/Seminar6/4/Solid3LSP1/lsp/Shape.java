package Seminar6.Solid3LSP1.lsp;

public abstract class Shape {
    public abstract int getArea();
}
