package Seminar6.Solid2OCP1.ocp;

public interface Shape {
    double getArea();
}
